 
<?php

     $username = 'root';
     $password = '';

     try {

         $db = new PDO('mysql:host=localhost;dbname=meusite_tads', $username, $password);
         $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

     } catch(PDOException $e) {

         echo 'ERROR: ' . $e->getMessage();

     }

 ?>