<?php

      // Chamando Conexao
      require_once('conexao/conexao.php'); 

     
      $page = $_SERVER['REQUEST_URI'];

      $url = explode('/', $page);

      if($url[2] == 'pagina-principal') :

           require_once('telas/login.php');

      elseif($url[2] == 'esqueceu-senha'):

      elseif(($url[1] <> "") AND (!$url[2])):

           require_once('telas/login.php');

      endif;

 ?>