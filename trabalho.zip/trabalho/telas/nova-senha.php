 <?php 
require_once('../conexao/conexao.php');


 ?>
 <!DOCTYPE html>
    <html> 

     <head>

         <meta charset="utf-8">
  
         <meta name="viewport" content="width=device-width, initial-scale=1, shrink-tofit=no">
  
         <title>Redefinir senha - Food-Waves</title>

         
             <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
         
             <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
         
             <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Noto+Serif+Tibetan&amp;display=swap">
         
             <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Scheherazade+New&amp;display=swap">
         
             <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Suranna&amp;display=swap">
         
             <link rel="stylesheet" href="../assets/fonts/fontawesome-all.min.css">    
         
             <link rel="stylesheet" href="../assets/fonts/font-awesome.min.css">
         
             <link rel="stylesheet" href="../assets/fonts/fontawesome5-overrides.min.css">
             
             <style type="text/css">
                 
                 body{ background-image:url('../assets/img/fundo.jpg'); }
 
             </style>
     </head>

     <body class="grad">
       
         <div class="container">
          
             <div class="row justify-content-center">
             
                 <div class="col-md-9 col-lg-12 col-xl-12">
                     
                     <div class="card shadow-lg o-hidden border-0 my-5">
                         
                         <div class="card-body p-0">
                             
                             <div class="row">
                                 
                                 <div class="col-lg-6 d-none d-lg-flex">
                                    
                                    <div class="flex-grow-1 bg-login-image " style="background-image: url('../assets/img/logo.png');"></div>
                               
                                 </div>
                                 
                                 <div class="col-lg-6">
                                     
                                     <div class="p-5">
                                         
                                         <div class="text-center">
                                             
                                             <h4 class="text-dark mb-4">Redefina sua Senha !</h4>
                                         </div>

                                           
                                         
                                         <form class="user" method="post" action="">

                                            <div class="form-group row">

                                                <div class="col-sm-6 mb-sm-0"><input type="password" name="password1" id="password1" class="form-control form-control-user" placeholder="Digite sua nova senha"></div>

                                                <div class="col-sm-6 mb-sm-0"><input type="password" name="password2" id="password2" class="form-control form-control-user" placeholder="Confirme sua nova senha"></div>
                                                
                                            </div>


                                             

                                         	
                                                                         
                                                         <div class="form-group">
                                                             
                                                             <div class="custom-control custom-checkbox small">

                                                            
                                                                 <button class="btn btn-success btn-block text-white btn-user"  type="submit"> Redefinir </button>
                                                                      
                                                             </div>
                                                                
                                                         </div><hr>
                                    
                                         </form>
                                        
                                         <div class="text-center"><a class="small" href="os/esqueceu-senha" style="color: #1cc88a;"> Esqueceu a senha ? </a></div>
                                    
                                              <div class="text-center"><a class="small" href="http://localhost/trabalho/" style="color: #1cc88a"> Ja tem uma conta? Conecte-se </a></div>
                                     </div>
                               
                                 </div>
                           
                             </div>
                       
                         </div>
                    
                     </div>
              
                 </div>
            
             </div>  

         </div>
             <script src="../assets/js/jquery.min.js"></script>
     
             <script src="../assets/js/bootstrap.min.js"></script>
     
             <script src="../assets/js/bs-init.js"></script>
     
             <script src="../assets/js/bootstrap.js"></script>
     
             <script src="../assets/js/bootstrap.min.js"></script>
     
             <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
     
             <script src="../assets/js/jquery.js"></script>
     
             <script src="../assets/js/jquery.min.js"></script>
     
             <script src="../assets/js/mdb.js"></script>
     
             <script src="../assets/js/mdb.min.js"></script>
     
             <script src="../assets/js/popper.js"></script>
     
             <script src="../assets/js/popper.min.js"></script>
     
             <script src="../assets/js/theme.js"></script>

     </body>

 </html>